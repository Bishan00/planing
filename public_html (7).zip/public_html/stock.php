<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        body {
            font-family: 'Cantarell', sans-serif;
            background-color: #F28018;
            color: #000000;
            margin: 0;
            padding: 0;
        }

        .container {
            padding: 20px;
        }

        .card {
            background-color: #FFFFFF;
            border: 1px solid #000000;
            border-radius: 10px;
            margin: 10px;
        }

        .card-header {
            background-color: #F28018;
            color: #FFFFFF;
            text-align: center;
            padding: 10px;
        }

        .card-body {
            padding: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid #000000;
            padding: 8px;
            text-align: center;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card mt-4">
                <div class="card-header">
                    <h4 class="text-center">Stock</h4>
                    <a href="stocklist.php"><button class="btn btn-primary">Search</button></a>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <tr class="header">
                            <th>Item Code</th>
                            <th>Tyre Name</th>
                            <th>Brand</th>
                            <th>Colour</th>
                            <th>RIM</th>
                            <th>Qty Stock</th>
                        </tr>
                        <tbody>
                            <?php
                            $con = mysqli_connect("localhost", "planatir_task_management", "Bishan@1919", "planatir_task_management");

                            $query = "SELECT * FROM realstock";
                            $query_run = mysqli_query($con, $query);

                            if (mysqli_num_rows($query_run) > 0) {
                                foreach ($query_run as $items) {
                                    ?>
                                    <tr>
                                        <td><?= $items['icode']; ?></td>
                                        <td><?= $items['t_size']; ?></td>
                                        <td><?= $items['brand']; ?></td>
                                        <td><?= $items['col']; ?></td>
                                        <td><?= $items['rim']; ?></td>
                                        <td><?= $items['cstock']; ?></td>
                                    <?php
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
