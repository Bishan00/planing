<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        body {
            font-family: 'Cantarell','open-sans';
            background-color: #F28018;
            color: #000000;
            margin: 0;
            padding: 0;
        }

        .container {
            padding: 20px;
        }

        .card {
            background-color: #FFFFFF;
            border: 1px solid #000000;
            border-radius: 10px;
            margin: 10px;
        }

        .card-header {
            background-color: #F28018;
            color: #FFFFFF;
            text-align: center;
            padding: 10px;
        }

        .card-body {
            padding: 20px;
        }

        .form-control {
            border: 1px solid #000000;
        }

        .btn-primary {
            background-color: #F28018;
            color: #FFFFFF;
            border: none;
        }

        .btn-primary:hover {
            background-color: #000000;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid #000000;
            padding: 8px;
            text-align: center;
        }

        .highlight {
            background-color: #F28018;
            color: #FFFFFF;
        }

        .center-enlarge {
            text-align: center;
            font-size: 18px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="text-center">Work Order</h4>
                    </div>
                    <div class="card-body">
                        <form action="" method="GET">
                            <div class="input-group mb-3">
                                <input type="text" name="search" required value="<?php if(isset($_GET['search'])){echo $_GET['search']; } ?>" class="form-control" placeholder="Enter ERP Number">
                                <button type="submit" class="btn btn-primary">Search</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <table class="table table-bordered">
                    <thead>
                        <tr class="header">
                            <th>NO</th>
                            <th>Item Code</th>
                            <th>Tire Size</th>
                            <th>Brand</th>
                            <th>Colour</th>
                            <th>FIT</th>
                            <th>Rim</th>
                            <th>Construction</th>
                            <th>Avg Finish Tyre Weight (kgs)</th>
                            <th>Per Volume (cbm)</th>
                            <th>Qty New pcs</th>
                            <th>Total Volume (cbm)</th>
                            <th>Total Tones (kgs)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $con = mysqli_connect("localhost", "planatir_task_management", "Bishan@1919", "planatir_task_management");

                        if (isset($_GET['search']) && !empty($_GET['search'])) {
                            $filtervalues = $_GET['search'];
                            $query = "SELECT * FROM worder WHERE CONCAT(erp) LIKE '%$filtervalues%' ";
                            $query_run = mysqli_query($con, $query);

                            if (mysqli_num_rows($query_run) > 0) {
                                $columnNumber = 1;

                                foreach ($query_run as $items) {
                                    ?>
                                    <tr>
                                        <td><?= $columnNumber++; ?></td>
                                        <td><?= $items['icode']; ?></td>
                                        <td><?= $items['t_size']; ?></td>
                                        <td><?= $items['brand']; ?></td>
                                        <td><?= $items['col']; ?></td>
                                        <td><?= $items['fit']; ?></td>
                                        <td><?= $items['rim']; ?></td>
                                        <td><?= $items['cons']; ?></td>
                                        <td><?= $items['fweight']; ?></td>
                                        <td><?= $items['ptv']; ?></td>
                                        <td><?= $items['new']; ?></td>
                                        <td><?= $items['cbm']; ?></td>
                                        <td><?= $items['kgs']; ?></td>
                                    </tr>
                                    <?php
                                }
                            } else {
                                ?>
                                <tr>
                                    <td colspan="13">No Record Found</td>
                                </tr>
                                <?php
                            }
                        } else {
                            $query = "SELECT DISTINCT erp FROM worder";
                            $query_run = mysqli_query($con, $query);

                            if (mysqli_num_rows($query_run) > 0) {
                                while ($erpRow = mysqli_fetch_assoc($query_run)) {
                                    $erp = $erpRow['erp'];

                                    $subQuery = "SELECT * FROM worder WHERE erp = '$erp'";
                                    $subQuery_run = mysqli_query($con, $subQuery);

                                    if (mysqli_num_rows($subQuery_run) > 0) {
                                        $columnNumber = 1;

                                        echo '<tr class="highlight"><td colspan="13" class="center-enlarge">ERP: ' . $erp . '</td></tr>';

                                        foreach ($subQuery_run as $items) {
                                            ?>
                                            <tr>
                                                <td><?= $columnNumber++; ?></td>
                                                <td><?= $items['icode']; ?></td>
                                                <td><?= $items['t_size']; ?></td>
                                                <td><?= $items['brand']; ?></td>
                                                <td><?= $items['col']; ?></td>
                                                <td><?= $items['fit']; ?></td>
                                                <td><?= $items['rim']; ?></td>
                                                <td><?= $items['cons']; ?></td>
                                                <td><?= $items['fweight']; ?></td>
                                                <td><?= $items['ptv']; ?></td>
                                                <td><?= $items['new']; ?></td>
                                                <td><?= $items['cbm']; ?></td>
                                                <td><?= $items['kgs']; ?></td>
                                            </tr>
                                            <?php
                                        }
                                    }
                                }
                            } else {
                                ?>
                                <tr>
                                    <td colspan="13">No Record Found</td>
                                </tr>
                                <?php
                            }
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
