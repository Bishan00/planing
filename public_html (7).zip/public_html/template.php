<html>

<form method="post" action="subtract.php">
    <button type="submit" name="subtract">Subtract Values</button>
</form>

</html>