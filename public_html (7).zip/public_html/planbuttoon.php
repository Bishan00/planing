<!DOCTYPE html>
<html>
<head>
  <style>
    body {
      font-family: 'Cantarell', sans-serif;
      background: url('atire2.jpg') center/cover no-repeat; /* Set the background image */
      display: flex;
      justify-content: center; /* Center horizontally */
      align-items: center; /* Center vertically */
      height: 100vh;
      margin: 0; /* Remove default margin for full-page background */
    }
    .container {
      text-align: center;
      display: grid;
      grid-template-columns: repeat(3, 1fr); /* 3 columns */
      gap: 10px; /* Gap between buttons */
      max-width: 600px; /* Adjust as needed */
    }
    .gradient-button {
      background: #F28018;
      color: #FFFFFF;
      font-family: 'Cantarell', sans-serif;
      font-weight: bold;
      font-size: 16px;
      border: none;
      width: 100%; /* Set the width to fill the grid cell */
      height: 60px; /* Set the button height */
      cursor: pointer;
      border-radius: 60px;
      text-transform: uppercase;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      transition: background 0.3s, color 0.3s;
    }
    .gradient-button:hover {
      background: #000000;
      color: #F28018;
    }
  </style>
</head>
<body>
    
  <div class="container">
    <form method="post" action="">
      <input type="submit" name="button1" value="All Plan" class="gradient-button">
    </form>
    <form method="post" action="">
      <input type="submit" name="button2" value="TO BE Produce All Work Orders" class="gradient-button">
    </form>
    <form method="post" action="">
      <input type="submit" name="button3" value="Individual Work Orders" class="gradient-button">
    </form>
    <form method="post" action="">
      <input type="submit" name="button4" value="Work Order Range" class="gradient-button">
    </form>
    <form method="post" action="">
      <input type="submit" name="button5" value="Plan Time Range" class="gradient-button">
    </form>
    <form method="post" action="">
      <input type="submit" name="button7" value="Time Range Compound Plan" class="gradient-button">
    </form>
    <form method="post" action="">
      <input type="submit" name="button8" value="All Compound Plan" class="gradient-button">
    </form>
  </div>
</body>
</html>



<?php
// Assuming you have established a connection to your MySQL database

// Function to execute MySQL queries
function executeQuery($query) {
    // Add your database connection code here

    // Execute the query
    $result = mysqli_query($connection, $query);

    // Check for errors
    if (!$result) {
        die("Query execution failed: " . mysqli_error($connection));
    }

    // Close the connection
    mysqli_close($connection);

    // Return the result
    return $result;
}

// Check if the button is clicked
if (isset($_POST['button1'])) {
    // Code to execute when Button 1 is clicked
    // Redirect to the desired page
    header("Location: planning.php");
    exit();
}

if (isset($_POST['button2'])) {
    // Code to execute when Button 2 is clicked
    // Redirect to the desired page
    header("Location: erprange.php");
    exit();
}

if (isset($_POST['button3'])) {
    // Code to execute when Button 3 is clicked
    // Redirect to the desired page
    header("Location: indwork.php");
    exit();
}

if (isset($_POST['button4'])) {
    // Code to execute when Button 3 is clicked
    // Redirect to the desired page
    header("Location: rangeerp.php");
    exit();
}


if (isset($_POST['button5'])) {
    // Code to execute when Button 3 is clicked
    // Redirect to the desired page
    header("Location: time_range3.php");
    exit();
}


if (isset($_POST['button7'])) {
    // Code to execute when Button 3 is clicked
    // Redirect to the desired page
    header("Location: time_range.php");
    exit();
}
if (isset($_POST['button8'])) {
    // Code to execute when Button 3 is clicked
    // Redirect to the desired page
    header("Location: compound2.php");
    exit();
}
?>