

<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="refresh" content="1;url=quickplan22.php">
</head>
<body>
<p>please wait generating the plan...</p>
</body>
</html>
