<?php
	$conn=mysqli_connect("localhost", "planatir_task_management", "Bishan@1919", "planatir_task_management");

	if(!$conn){
		die(mysqli_error());
	}
?>