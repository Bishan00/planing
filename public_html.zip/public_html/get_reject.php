<?php
// Database connection parameters
$host = 'localhost';
$username = 'planatir_task_management';
$password = 'Bishan@1919';
$database = 'planatir_task_management';

// Create a database connection
$mysqli = new mysqli($host, $username, $password, $database);

// Check the connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// SQL query to retrieve data from the template table
$query = "SELECT * FROM template";

// Execute the query
$result = $mysqli->query($query);

if ($result) {
    echo "<table border='1'>";
    echo "<tr><th>Item Code</th><th>Description</th><th>No Of Reject</th><th>Date</th><th>Shift</th></tr>";

    // Fetch and display data
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['icode'] . "</td>";

         // Query the tire table for the description based on the icode
         $tireQuery = "SELECT description FROM tire WHERE icode = '{$row['icode']}'";
         $tireResult = $mysqli->query($tireQuery);
 
         if ($tireResult && $tireRow = $tireResult->fetch_assoc()) {
             echo "<td>" . $tireRow['description'] . "</td>";
         } else {
             echo "<td>No description found</td>";
         }

        echo "<td>" . $row['cstock'] . "</td>";
        echo "<td>" . $row['date'] . "</td>";
        echo "<td>" . $row['shift'] . "</td>";

       

        echo "</tr>";
    }

    echo "</table>";

    // Free the result sets
    $result->free();
} else {
    echo "Error: " . $mysqli->error;
}

// Close the database connection
$mysqli->close();
?>
