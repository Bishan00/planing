<!DOCTYPE html>
<html>
<head>
    <title>ERP Data Search</title>
</head>
<body>
    <h1>Search ERP Data</h1>
    <form action="dispatch2.php" method="post">
        ERP Number: <input type="text" name="erp_number" required>
        <input type="submit" value="Search">
    </form>
</body>
</html>
