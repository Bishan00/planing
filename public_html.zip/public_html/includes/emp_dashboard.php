

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        /* Styling for the Dashboard elements */
        .element-content {
    background-color: #F28018;
    padding: 0;
    text-align: center;
    box-shadow: 2px 2px 4px rgba(0, 0, 10, 100);
    
    /* Make the element fill the full page */
    position: right;
    top: 0;
    left: 5px;
    width: 100%;
    height: 100%;
}



        .element-box {
            background-color: #FFFFFF;
            padding: 20px;
            border-radius: 60px;
            margin: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            
        }

        .element-header {
            color: #000000;
            font-size: 24px;
            font-weight: bold;
        }

        .element-box a {
            text-decoration: none;
            color: #F28018;
        }

        /* Styling for the specific elements with id="myDIV" */
        #myDIV {
            color: #000000;
            font-weight: bold;
            font-size: 20px;
            margin-top: 10px;
        }

        
    body {
        background-color: #FFFFFF;
    }


    </style>
    <title>Your Dashboard</title>
</head>
<body>
    <div class="element-content">
    <h6 style="background-color: #000000; color: #fff; border-radius: 50px; padding: 3px; text-align: center; font-weight: bold; font-family: 'Cantarell', sans-serif;">Dashboard - Repots</h6>
    

            <div class="col-sm-4 col-xxxl-3">
                <a class="element-box el-tablo" href="daily_production.php">
                    <div id="myDIV">Daily Production </div>
                </a>
            </div><br>
<div>
            <div class="col-sm-4 col-xxxl-3">
                <a class="element-box el-tablo" href="planbuttoon.php">
                    <div id="myDIV">Planing Reports</div>
                </a>
            </div>
            <p class="red-text">ddddddddddddddddddd</p>
  <p class="red-text">ddddddddd</p>
  <p class="blue-text">ddddddd</p>
  <p class="red-text">dddddddddddd</p>
  <p class="red-text">dddddddddddddddddd</p>
  <p class="red-text">dddddddddddddddddd</p>
  <p class="red-text">dddddddddddddddddd</p>
  <p class="red-text">dddddddddddddddddd</p>
  <p class="red-text">ddddddddddddddddddd</p>

           
           
        </div>
    </div>
</body>
</html>
