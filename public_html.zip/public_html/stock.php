<!DOCTYPE html>
<html>

<head>
    <style>
        /* Your CSS styles */
        .container {
            margin: 0 auto;
            max-width: 1200px;
            padding: 20px;
            background-color: #f0f0f0;
        }

        .stock-table {
            width: 100%;
            border-collapse: collapse;
        }

        .stock-table th,
        .stock-table td {
            border: 1px solid #000000;
            padding: 10px;
            text-align: left;
        }

        .stock-table th {
            background-color: #F28018;
            color: #000000;
            font-family: 'Cantarell', sans-serif;
            font-weight: bold;
        }

        .button-container {
            text-align: left;
            margin: 10px;
            border-radius: 4px;
        }

        .button-container button {
            background-color: #000000;
            color: #FFFFFF;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            border-radius: 40px;
        }

        .search-form {
            text-align: center;
            margin: 10px;
        }

        .search-form input[type="text"] {
            padding: 10px;
            width: 200px;
            border: 1px solid #CCCCCC;
            border-radius: 4px;
            font-family: 'Cantarell', sans-serif;
            font-weight: regular;
        }

        .search-form button {
            background-color: #000000;
            color: #FFFFFF;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .button-container button {
            background-color: #000000;
            color: #FFFFFF;
            padding: 10px 20px;
            border: none;
            border-radius: 40px;
            cursor: pointer;
            transition: background-color 0.3s; /* Add a smooth transition for the background color change */
        }

        .button-container button:hover {
            background-color: #333333; /* Change the background color on hover */
        }

        .stock-row td {
            font-family: 'Open Sans', sans-serif;
            font-weight: regular;
        }
    </style>

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cantarell:regular,bold,700|Open+Sans:regular,bold,700&display=swap" />
    <script>
        function searchStock() {
            var input = document.getElementById('icodeInput').value;
            var table = document.getElementById('stock-table');
            var rows = table.getElementsByClassName('stock-row');

            for (var i = 0; i < rows.length; i++) {
                var cell = rows[i].getElementsByTagName('td')[0];
                if (cell) {
                    var cellValue = cell.textContent || cell.innerText;

                    if (cellValue === input) {
                        rows[i].style.display = "";
                    } else {
                        rows[i].style.display = "none";
                    }
                }
            }
        }
    </script>
</head>

<body>
     <!-- Button container in the top-left corner -->
     <div class="button-container">
    <button>
        <a href="dashboard.php" style="text-decoration: none; color: #FFFFFF;">Click To dashboard</a>
    </button>
</div>

    <!-- Add the container for the stock information -->
    <div class="container">
        <div class="search-form">
            <input type="text" id="icodeInput" placeholder="Enter Item Code">
            <button onclick="searchStock()">Search</button>
        </div>
        <table id="stock-table" class="stock-table">
            <tr class="header">
                <th>Item Code</th>
                <th>Tyre Name</th>
                <th>Brand</th>
                <th>Colour</th>
                <th>RIM</th>
                <th>Qty Stock</th>
            </tr>
            <tbody>
                <?php
                $con = mysqli_connect("localhost", "planatir_task_management", "Bishan@1919", "planatir_task_management");

                $query = "SELECT * FROM realstock";
                $query_run = mysqli_query($con, $query);

                if (mysqli_num_rows($query_run) > 0) {
                    while ($items = mysqli_fetch_assoc($query_run)) {
                        ?>
                        <tr class="stock-row">
                            <td><?= $items['icode']; ?></td>
                            <td><?= $items['t_size']; ?></td>
                            <td><?= $items['brand']; ?></td>
                            <td><?= $items['col']; ?></td>
                            <td><?= $items['rim']; ?></td>
                            <td><?= $items['cstock']; ?></td>
                        </tr>
                    <?php
                }
            }
            ?>
            </tbody>
        </table>
    </div>
</body>

</html>
